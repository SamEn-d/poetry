# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['poetry']

package_data = \
{'': ['*']}

install_requires = \
['pytest==7.1.2', 'selene>=2.0.b4,<3.0']

setup_kwargs = {
    'name': 'poetry',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Sam',
    'author_email': 'w@wth.ru',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
